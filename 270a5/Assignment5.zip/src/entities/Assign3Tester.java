package entities;

/** A class to test the entity classes of assignment #3. */
public class Assign3Tester {

	/**
	 * The driver for the testing.
	 */
	public static void main(String[] args) 
	{
		Person.main(null);
		System.out.println();
		Booking.main(null);
		System.out.println();
		BasicFlight.main(null);
		System.out.println();
		Passenger.main(null);
		System.out.println();
		FirstClassBooking.main(null);
		System.out.println();
		Flight.main(null);
	}

}
