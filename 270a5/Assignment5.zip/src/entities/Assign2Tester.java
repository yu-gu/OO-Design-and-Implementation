package entities;

public class Assign2Tester {

	public static void main(String[] args) 
	{
		Person.main(null);
		System.out.println();
		Booking.main(null);
		System.out.println();
		BasicFlight.main(null);
	}
}
